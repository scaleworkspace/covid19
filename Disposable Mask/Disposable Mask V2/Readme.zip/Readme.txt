Instructions	

Print (2) of each .stl file attached:"Disposable Mask Top Rev 2" and "Disposable Mask Bottom Rev 2"

Cut a 7.5”x 5” piece of cotton T shirt or use the .dxf provided to lasercut

Clasp P1 and P2 together on either side of the cloth along the 5" edge

Use (2) Rubber bands to loop inside open holes and around your ears, covering your mouth and nose