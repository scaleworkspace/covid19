Instructions	

Print 1 "Respirator Style Mask.stl" at .2mm Layer height in any available material

Cut a 4”x 4” piece of cotton T shirt or use the .dxf provided to lasercut

Use a rubber band to secure the cotton to the mask using the groove provided

You may double or triple the layers of cotton if you'd like